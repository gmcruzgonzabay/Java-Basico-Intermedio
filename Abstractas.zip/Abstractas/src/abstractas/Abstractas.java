/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractas;

/**
 *
 * @author gregoriocruz
 */
public class Abstractas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        Cuadrado cuadrado =new Cuadrado(10,20,"Amarillo");
        Triangulo triangulo=new Triangulo(15,20,"Rojo");
        double resultado;
        
       // resultado=cuadrado.CalcularArea();
        System.out.println("***El area de un Cuadrado");
        System.out.println("El area es:"+cuadrado.CalcularArea());
        
        resultado=triangulo.CalcularArea();
        System.out.println("***EL area de un Triangulo***");
        System.out.println("El area es:"+resultado);
        
        
        
    }
    
}
