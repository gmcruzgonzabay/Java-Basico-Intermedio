/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractas;
import java.lang.*;

/**
 *
 * @author gregoriocruz
 */
public class Matematicas 
{
     public static void main(String[] args) 
    {
       try
       {
        int a,b;
        double res;
        a=5;
        b=0;
        res=a/b;
       }
       catch(ArithmeticException e )
       {
                System.out.println("Este es el ");   
       }
        
    }
    
}
