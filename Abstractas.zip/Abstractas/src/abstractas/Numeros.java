/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractas;

/**
 *
 * @author gregoriocruz
 */
import java.awt.TextArea;
import java.lang.*;
import java.util.InputMismatchException; 
import java.util.Scanner; 
import javax.swing.JOptionPane;
public class Numeros
  { 
        public static void main(String[] args) 
            { 
               
               int a,b,z=-1;
               String test1;
               TextArea area=new TextArea();
               Scanner entrada= new Scanner(System.in);
             do
             {
               try
               {
                  a=Integer.parseInt(JOptionPane.showInputDialog("Ingrese numero 1"));
                   //System.out.println("Ingrese numero 1:");
                   //a=entrada.nextInt();
                     b=Integer.parseInt(JOptionPane.showInputDialog("Ingrese numero 2"));
                
                  // System.out.println("Ingrese numero 2:");
                   b=entrada.nextInt();
                   
                   z=a+b;
                //   area.setText(z);
                   
                   
                   
               }
               catch(java.util.InputMismatchException e)
               {
                   System.out.println("Debe ingresar letras");
                   entrada.next();
               }
             }while(z!=0);
               
                
            } 

} 
