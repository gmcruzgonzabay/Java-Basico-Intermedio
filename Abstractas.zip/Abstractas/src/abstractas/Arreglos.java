/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractas;

/**
 *
 * @author gregoriocruz
 */
public class Arreglos 
{
    public static void main(String[] args) 
    {
        String array[][]= new String[2][2];
        int array1[][]=new int[3][3];
        int i,j,a=1;
        for(i=0;i<=array1.length-1;i++)
        {
            for(j=0;j<=array1.length-1;j++)
            {
                
                array1[i][j]=a;
               a++; 
            }
            
        }
       
         for(i=0;i<=array1.length-1;i++)
        {
            for(j=0;j<=array1.length-1;j++)
            {
                  System.out.print(""+array1[i][j]);
            }
            System.out.println("");
        }
        
     
        
        
        
    }
}
