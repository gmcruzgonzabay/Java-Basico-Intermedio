/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author gregoriocruz
 */
@WebServlet(name = "Guardar", urlPatterns = {"/Guardar"})
public class Guardar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
            //Capturo los datos del formulario y los almaceno en una varible
            //La variable que va en getParameter es el nombre de la caja de
            //texto la cual ud creo en la pagina principal
            String nombres=request.getParameter("nombres");
            String apellidos=request.getParameter("apellidos");
            String direccion=request.getParameter("direccion");
            
            //Invoco a la conexion
            //creo una variable de tipo persona la cual maneja la conexion
            conexion.Persona persona=new conexion.Persona();
            
            //empiezo a enviar los datos que se van almacenar
           persona.setNombres(nombres);
           persona.setApellidos(apellidos);
            persona.setDireccion(direccion);
            //Lo que hace la clase es crearme automaticamente los metodos set
            //con los cuales voy a enviar la informacion para actualizar
            
            //Creo una variable de tipo EntityManager para manejar la conexion
            //e insertar los datos
            
            EntityManager em;
            EntityManagerFactory emf;
            //Aqui le digo que voy a utilizar persistencia con el proyecto
            
            emf=Persistence.createEntityManagerFactory("webSistemPU");
            em=emf.createEntityManager();
            //Preparo la transaccion que va a utilizar persistencia
            em.getTransaction().begin();
            //le indico con que clase voy a utilzar persistencia
            em.persist(persona);
            em.flush(); //limpio objetos obsoletos en memoria
            em.getTransaction().commit(); //ejecuto la transaccion
            response.sendRedirect("correcto.jsp"); //redirecciono a una pagina
            
            
            
            
            
            
            
            
            
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
