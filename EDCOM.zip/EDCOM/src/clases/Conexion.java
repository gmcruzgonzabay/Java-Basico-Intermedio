/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author gregoriocruz
 */
public class Conexion 
{
     //Importar el driver de conexion
    Connection conexion=null;
    public Connection ConectaBase()
    {
        Connection con=null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver"); //Nombre del Driver de Conexion       
            //Indico a que base de datos me voy a conectar e indico el usuario y la clave
            con=DriverManager.getConnection("jdbc:mysql://localhost/curso","root","");
            System.out.println("Se conecto exitosamente");
            
        }
        catch(Exception e)
        {
            System.out.println("Ocurrio un error de conexion"+e);
        }
        
        return con;
    }
    
}
